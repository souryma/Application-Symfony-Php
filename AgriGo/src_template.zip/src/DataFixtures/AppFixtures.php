<?php

namespace App\DataFixtures;

use App\Entity\Producteur;
use App\Entity\Produit;
use App\Entity\Variete;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        // $product = new Product();
        // $manager->persist($product);
        $Jacky = new Producteur();
        $Jacky->setNomProducteur('Jacky');
        $Jacky->setImageProducteur('img/Jacky.png');
        $Jacky->setPrenomProducteur('Lpere');
        $Jacky->setNumRue('5');
        $Jacky->setNomRue('Rue de chez Jacky');
        $Jacky->setVilleProducteur('La rochelle');
        $Jacky->setCodePostal('17000');
        $Jacky->setMailProducteur('JAcky@exemple.net');
        $Jacky->setNomMagasin('Chez Jacky');
        $Jacky->setNumTelProducteur('0102030405');

        $cerise = new Produit();
        $cerise->setTypeProduit('cerise');
        $cerise->setCategorieProduit('fruit');
        $cerise->setImageProduit('img/cerise.png');
        $cerise->setDescriptionProduit('description.txt');

        $carotte = new Produit();
        $carotte->setTypeProduit('carotte');
        $carotte->setCategorieProduit('legume');
        $carotte->setImageProduit('img/carotte.png');
        $carotte->setDescriptionProduit('description.txt');

        $rouge = new Variete();
        $rouge->setImageVariete('img/ceriseRouge.png');
        $rouge->setNomVariete('cerise rouge');
        $rouge->setTypeVariete($cerise);
        $rouge->setProducteurVariete($Jacky);

        $vert = new Variete();
        $vert->setImageVariete('img/ceriseVerte.png');
        $vert->setNomVariete('cerise vert');
        $vert->setTypeVariete($cerise);
        $vert->setProducteurVariete($Jacky);

        $jaune = new Variete();
        $jaune->setImageVariete('img/ceriseJaune.png');
        $jaune->setNomVariete('cerise jaune');
        $jaune->setTypeVariete($cerise);
        $jaune->setProducteurVariete($Jacky);

        $oeuf = new Produit();
        $oeuf->setTypeProduit('oeuf');
        $oeuf->setCategorieProduit('autre');
        $oeuf->setImageProduit('img/oeuf.png');
        $oeuf->setDescriptionProduit('Lœuf est un produit agricole issu délevages divers et utilisé comme aliment humain simple ou servant dingrédient dans la composition de nombreux plats dans la plupart des cultures du monde. ');

        $oeufPoule = new Variete();
        $oeufPoule->setImageVariete('img/oeufPoule.png');
        $oeufPoule->setNomVariete('Oeuf de Poule');
        $oeufPoule->setTypeVariete($oeuf);
        $oeufPoule->setProducteurVariete($Jacky);

        $oeufAutruche = new Variete();
        $oeufAutruche->setImageVariete('img/oeufAutruche.png');
        $oeufAutruche->setNomVariete('Oeuf d autruche');
        $oeufAutruche->setTypeVariete($oeuf);
        $oeufAutruche->setProducteurVariete($Jacky);


        $aubergine = new Produit();
        $aubergine->setTypeProduit('aubergine');
        $aubergine->setCategorieProduit('legume');
        $aubergine->setImageProduit('img/aubergine.png');
        $aubergine->setDescriptionProduit('description.txt');

        $pommeDeTerre = new Produit();
        $pommeDeTerre->setTypeProduit('pomme de terre');
        $pommeDeTerre->setCategorieProduit('feculent');
        $pommeDeTerre->setImageProduit('img/patate.png');
        $pommeDeTerre->setDescriptionProduit('description.txt');

        $Haricot = new Produit();
        $Haricot->setTypeProduit('$haricot Vert');
        $Haricot->setCategorieProduit('legume');
        $Haricot->setImageProduit('img/haricot.png');
        $Haricot->setDescriptionProduit('description.txt');

        $TomateLegume = new Produit();
        $TomateLegume->setTypeProduit('Tomate');
        $TomateLegume->setCategorieProduit('legume');
        $TomateLegume->setImageProduit('img/tomate.png');
        $TomateLegume->setDescriptionProduit('description.txt');

        $Haricot = new Produit();
        $Haricot->setTypeProduit('Haricot Vert');
        $Haricot->setCategorieProduit('legume');
        $Haricot->setImageProduit('img/haricot.png');
        $Haricot->setDescriptionProduit('description.txt');

        $Courgette = new Produit();
        $Courgette->setTypeProduit('Courgette');
        $Courgette->setCategorieProduit('legume');
        $Courgette->setImageProduit('img/courgette.png');
        $Courgette->setDescriptionProduit('description.txt');

        $Poivron = new Produit();
        $Poivron->setTypeProduit('Poivron');
        $Poivron->setCategorieProduit('legume');
        $Poivron->setImageProduit('img/poivron.png');
        $Poivron->setDescriptionProduit('description.txt');

        $Poireaux = new Produit();
        $Poireaux->setTypeProduit('Poireaux');
        $Poireaux->setCategorieProduit('legume');
        $Poireaux->setImageProduit('img/poireaux.png');
        $Poireaux->setDescriptionProduit('description.txt');

        $Salade = new Produit();
        $Salade->setTypeProduit('Salade');
        $Salade->setCategorieProduit('legume');
        $Salade->setImageProduit('img/salade.png');
        $Salade->setDescriptionProduit('description.txt');

        $manager->persist($Jacky);
        $manager->persist($cerise);
        $manager->persist($carotte);
        $manager->persist($rouge);
        $manager->persist($vert);
        $manager->persist($jaune);
        $manager->persist($oeuf);
        $manager->persist($oeufPoule);
        $manager->persist($oeufAutruche);
        $manager->persist($carotte);
        $manager->persist($aubergine);
        $manager->persist($pommeDeTerre);
        $manager->persist($aubergine);
        $manager->persist($Haricot);
        $manager->persist($Courgette);
        $manager->persist($Poivron);
        $manager->persist($Poireaux);
        $manager->persist($Salade);
        $manager->flush();
    }
}
